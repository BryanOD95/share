# -*- coding: utf-8 -*-
"""
Created on Wed Jul 27 10:55:53 2022

@author: bryan.odonohoe
"""

import os
os.environ["HOME"]  = "./"

print("HOME" in os.environ)

import opennre

model = opennre.get_model('wiki80_cnn_softmax')

print(model.infer({'text': 'He was the son of Máel Dúin mac Máele Fithrich, and grandson of the high king Áed Uaridnach (died 612).', 'h': {'pos': (18, 46)}, 't': {'pos': (78, 91)}}))