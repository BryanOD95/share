# -*- coding: utf-8 -*-
"""
Created on Thu Jul 28 09:34:55 2022

@author: bryan.odonohoe
"""
import functools
from typing import Dict

import streamlit as st  # type: ignore
from transformers import Pipeline, pipeline  # type: ignore

from config import config

import OpenNRE.opennre 

model = opennre.get_model('wiki80_cnn_softmax')


def conditional_decorator(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        if config["framework"] == "pt":
            qa = st.cache(func)(*args, **kwargs)
        else:
            qa = func(*args, **kwargs)
        return qa

    return wrapper


@conditional_decorator
def get_RE_pipeline() -> Pipeline:
    qa = pipeline("question-answering", model = opennre.get_model('wiki80_cnn_softmax'), framework=config["framework"])
    return qa


@conditional_decorator
def answer_question(pipeline: Pipeline, question: str, paragraph: str) -> Dict:
    input = {"question": question, "context": paragraph}
    return pipeline(input)


def format_text(paragraph: str, start_idx: int, end_idx: int) -> str:
    return (
        paragraph[:start_idx]
        + "**"
        + paragraph[start_idx:end_idx]
        + "**"
        + paragraph[end_idx:]
    )


if __name__ == "__main__":
    """
    """
    paragraph_slot = st.empty()
    text = st.text_input("String to analyse", "")
    Entity1 = st.text_input("Entity 1", "")
    Entity2 = st.text_input("Entity 2", "")
    
    if (text.find(Entity1) != -1):
        hPosStart = text.find(Entity1)
    else:
        st.warning("You must provide an Entity present in the string")
        
    if (text.find(Entity2) != -1):
        tPosStart = text.find(Entity2)
    else:
        st.warning("You must provide an Entity present in the string")
    hPosEnd = text.find(Entity1) + len(Entity1)
    tPosEnd = text.find(Entity2) + len(Entity2)
    
    modelInput = "{'text': '" + str(text) + "', 'h': {'pos': (" + str(hPosStart) + ", " +  str(hPosEnd) + ")}, 't': {'pos': (" + str(tPosStart) + ", " + str(tPosEnd) + ")}}"

    
    if (text):        
        # Execute question against paragraph
        if modelInput != "":
            pipeline = get_RE_pipeline()
            try:
                # answer = answer_question(pipeline, modelInput)
                # start_idx = answer["start"]
                # end_idx = answer["end"]
                # st.success(answer["answer"])
                print(model.infer(modelInput))
                
                # print(f"FRAMEWORK: {config['framework']}")
                # print(f"QUESTION: {question}\nRESPONSE: {answer}")
            except Exception as e:
                print(e)
                st.warning("You must provide a valid wikipedia paragraph")